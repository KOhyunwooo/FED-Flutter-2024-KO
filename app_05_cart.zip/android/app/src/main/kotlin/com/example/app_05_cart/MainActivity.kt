package com.example.app_05_cart

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
