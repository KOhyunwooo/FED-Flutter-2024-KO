// 정해진 규격 사이즈를 변수에 미리할당함!
const double smallGap = 5.0;
const double mediumGap = 10.0;
const double largeGap = 20.0;
const double xlargeGap = 100.0;
