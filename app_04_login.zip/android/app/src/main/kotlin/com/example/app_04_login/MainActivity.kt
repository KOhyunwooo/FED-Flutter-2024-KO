package com.example.app_04_login

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
